export const testimonials = [
  {
    name: "Emily",
    title: "Global Social Lead",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "WhatsApp gave me freedom to lead campaigns from anywhere in the world. The tools and team support make remote work incredibly productive."
  },
  {
    name: "Daniel",
    title: "Content Marketing Manager",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "Working remotely for WhatsApp means I can collaborate with a global team while maintaining the perfect work-life balance. The flexibility is unmatched."
  },
  {
    name: "Sophia",
    title: "Social Media Strategist",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "The remote culture at WhatsApp empowers me to do my best work. I can connect with users across markets while working from my home country."
  },
  {
    name: "Michael",
    title: "UX Research Lead",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "WhatsApp's remote framework let me build a diverse research team spanning five continents. We bring different cultural perspectives that have significantly improved our product design."
  },
  {
    name: "Priya",
    title: "Community Manager",
    image: "https://images.unsplash.com/photo-1534751516642-a1af1ef26a56?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "Being able to work from my home in Mumbai while connecting with WhatsApp users globally has been an incredible journey. I've grown professionally in ways I never expected."
  }
];

export const jobs = [
  // Marketing Jobs
  {
    id: "senior-content-strategist",
    title: "Senior Content Strategist",
    department: "Marketing",
    location: "Remote (Americas/EMEA)",
    salary: "$85,000 – $130,000 USD/year",
    workingHours: "Flexible / GMT±4",
    responsibilities: "Lead content strategy for global marketing campaigns, working with stakeholders to create compelling narratives that resonate with our diverse user base.",
    requirements: [
      "5+ years of experience in content strategy, preferably in tech",
      "Exceptional writing and editing skills",
      "Experience with global/multicultural content adaptation",
      "Bachelor's degree in Marketing, Communications, or related field"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Unlimited PTO",
      "Learning & development budget"
    ],
    jobDetailsFile: "job-details-senior-content-strategist.pdf",
    applicationFormFile: "application-form-senior-content-strategist.pdf",
    featured: true
  },
  {
    id: "social-media-manager",
    title: "Social Media Manager",
    department: "Marketing",
    location: "Remote (EMEA/APAC)",
    salary: "$70,000 – $95,000 USD/year",
    workingHours: "Flexible / GMT±2",
    responsibilities: "Develop and execute social media strategies that amplify WhatsApp's mission and features across platforms while engaging with our global community.",
    requirements: [
      "3+ years of experience in social media management",
      "Excellent communication and copywriting skills",
      "Experience with global social media campaigns",
      "Proficiency with social media analytics tools"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Wellness stipend",
      "Remote work equipment allowance"
    ],
    jobDetailsFile: "job-details-social-media-manager.pdf",
    applicationFormFile: "application-form-social-media-manager.pdf",
    featured: false
  },
  {
    id: "digital-marketing-specialist",
    title: "Digital Marketing Specialist",
    department: "Marketing",
    location: "Remote (Americas/APAC)",
    salary: "$65,000 – $90,000 USD/year",
    workingHours: "Flexible / GMT±6",
    responsibilities: "Plan and execute digital marketing campaigns across multiple channels to drive user acquisition and engagement for WhatsApp's global audience.",
    requirements: [
      "2+ years of digital marketing experience",
      "Experience with paid social, SEM, and display advertising",
      "Strong analytical skills and familiarity with marketing analytics",
      "Bachelor's degree in Marketing or related field"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Professional development opportunities",
      "Flexible work schedule"
    ],
    jobDetailsFile: "job-details-digital-marketing-specialist.pdf",
    applicationFormFile: "application-form-digital-marketing-specialist.pdf",
    featured: true
  },
  
  // Design Jobs
  {
    id: "ux-designer",
    title: "UX Designer",
    department: "Design",
    location: "Remote (Global)",
    salary: "$80,000 – $120,000 USD/year",
    workingHours: "Flexible / Any timezone",
    responsibilities: "Create intuitive, accessible user experiences for WhatsApp features across platforms, working closely with product managers and engineers to implement user-centered design solutions.",
    requirements: [
      "3+ years experience in UX design for mobile applications",
      "Strong portfolio demonstrating user-centered design process",
      "Experience with design systems and component libraries",
      "Proficiency with Figma, Sketch or similar design tools"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Design conference attendance stipend",
      "Creative tools subscription"
    ],
    jobDetailsFile: "job-details-ux-designer.pdf",
    applicationFormFile: "application-form-ux-designer.pdf",
    featured: false
  },
  {
    id: "product-designer",
    title: "Product Designer",
    department: "Design",
    location: "Remote (Americas/EMEA)",
    salary: "$90,000 – $135,000 USD/year",
    workingHours: "Flexible / GMT±5",
    responsibilities: "Lead end-to-end product design for WhatsApp features, from concept to implementation, balancing user needs with business goals and technical constraints.",
    requirements: [
      "4+ years of product design experience for consumer applications",
      "Experience leading design projects from concept to launch",
      "Strong understanding of design systems and accessibility standards",
      "Knowledge of user research methodologies and data-informed design"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Annual home office upgrade stipend",
      "Education reimbursement"
    ],
    jobDetailsFile: "job-details-product-designer.pdf",
    applicationFormFile: "application-form-product-designer.pdf",
    featured: true
  },
  
  // Community Jobs
  {
    id: "community-manager",
    title: "Community Manager",
    department: "Community",
    location: "Remote (APAC focused)",
    salary: "$60,000 – $85,000 USD/year",
    workingHours: "Flexible / GMT+5 to GMT+11",
    responsibilities: "Build and nurture WhatsApp communities in the APAC region, develop community programs, and represent the voice of users to product teams.",
    requirements: [
      "3+ years of community management experience",
      "Fluency in English and at least one Asian language",
      "Experience managing online communities and organizing events",
      "Strong communication and relationship-building skills"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Wellness program",
      "Internet stipend"
    ],
    jobDetailsFile: "job-details-community-manager.pdf",
    applicationFormFile: "application-form-community-manager.pdf",
    featured: false
  },
  
  // Business Development Jobs
  {
    id: "business-development-manager",
    title: "Business Development Manager",
    department: "Business Development",
    location: "Remote (EMEA/LATAM)",
    salary: "$85,000 – $120,000 USD/year",
    workingHours: "Flexible / GMT-3 to GMT+3",
    responsibilities: "Identify and develop strategic partnerships for WhatsApp Business, expand the platform's reach, and drive adoption of WhatsApp's business tools in emerging markets.",
    requirements: [
      "5+ years of business development or partnership experience",
      "Experience in SaaS, mobile apps, or messaging platforms",
      "Strong negotiation and relationship management skills",
      "Knowledge of emerging markets in EMEA or LATAM regions"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Quarterly performance bonuses",
      "International travel opportunities"
    ],
    jobDetailsFile: "job-details-business-development-manager.pdf",
    applicationFormFile: "application-form-business-development-manager.pdf",
    featured: true
  },
  
  // Customer Success Jobs
  {
    id: "customer-success-specialist",
    title: "Customer Success Specialist",
    department: "Customer Success",
    location: "Remote (Americas)",
    salary: "$55,000 – $75,000 USD/year",
    workingHours: "Flexible / GMT-8 to GMT-3",
    responsibilities: "Support businesses using WhatsApp Business API, provide product education, and ensure customers are maximizing the value of WhatsApp's business tools.",
    requirements: [
      "2+ years of customer success or support experience",
      "Experience with CRM systems and support tools",
      "Excellent problem-solving and communication skills",
      "Fluency in English and Spanish"
    ],
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance",
      "Mental health support program",
      "Professional certification support"
    ],
    jobDetailsFile: "job-details-customer-success-specialist.pdf",
    applicationFormFile: "application-form-customer-success-specialist.pdf",
    featured: false
  }
];

import { useEffect } from "react";
import { Link } from "wouter";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { testimonials } from "@/lib/data";

const TestimonialsPage = () => {
  const { ref, isVisible } = useScrollAnimation();

  // Add title when component mounts
  useEffect(() => {
    document.title = "Testimonials | WhatsApp Careers";
  }, []);

  return (
    <div className="flex flex-col pt-24 pb-16">
      <div className="bg-gradient-to-br from-[rgba(37,211,102,0.1)] to-[rgba(37,211,102,0.05)] py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Employee Stories</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            Hear directly from our team members about what it's like to work at WhatsApp remotely from around the world.
          </p>
        </div>
      </div>

      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className={`bg-white rounded-lg shadow-md overflow-hidden transition-all duration-700 ease-in-out ${
                isVisible 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="p-6">
                <div className="flex items-center justify-center mb-6">
                  <img 
                    className="h-24 w-24 rounded-full object-cover" 
                    src={testimonial.image} 
                    alt={`${testimonial.name} profile photo`} 
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-medium text-gray-900">{testimonial.name}</h3>
                  <p className="text-[#25D366] font-medium">{testimonial.title}</p>
                  <div className="mt-4 italic text-gray-600">
                    <p>"{testimonial.quote}"</p>
                  </div>
                  <div className="mt-4 flex justify-center">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="text-[#25D366] h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-[#25D366] rounded-lg shadow-xl overflow-hidden">
          <div className="px-6 py-12 md:p-12 md:flex md:items-center md:justify-between">
            <div className="max-w-3xl">
              <h2 className="text-3xl font-bold text-white">Featured Interview</h2>
              <p className="mt-6 text-xl text-white">
                "Working at WhatsApp has completely transformed my career. The remote-first approach has given me the freedom to do my best work while maintaining work-life balance."
              </p>
              <div className="mt-8 flex items-center">
                <div className="flex-shrink-0">
                  <img 
                    className="h-12 w-12 rounded-full" 
                    src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80" 
                    alt="Michael profile photo" 
                  />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-white">Michael Johnson</h3>
                  <p className="text-white opacity-90">UX Research Lead</p>
                </div>
              </div>
            </div>
            <div className="mt-8 md:mt-0">
              <a
                href="#"
                className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-[#25D366] bg-white hover:bg-gray-50"
              >
                Read Full Interview
                <svg className="ml-2 -mr-1 h-5 w-5 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gray-50 py-16 px-4 sm:px-6 lg:px-8 mt-8">
        <div className="max-w-7xl mx-auto">
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="lg:w-1/2">
              <h2 className="text-3xl font-bold text-gray-900">Join Our Global Team</h2>
              <p className="mt-4 text-lg text-gray-600">
                Become part of a talented team of professionals working to connect billions of people around the world. Explore remote opportunities at WhatsApp.
              </p>
            </div>
            <div className="mt-8 lg:mt-0 lg:w-1/2 lg:flex lg:justify-end">
              <Link href="/jobs">
                <a className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#25D366] hover:bg-[#34eb75] shadow">
                  View Open Positions
                  <svg className="ml-2 -mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </a>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestimonialsPage;
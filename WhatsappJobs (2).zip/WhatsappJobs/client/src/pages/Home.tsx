import { useEffect } from "react";
import { Link } from "wouter";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { jobs } from "@/lib/data";
import ApplicationFormDialog from "@/components/ApplicationFormDialog";
import ApplicationFormPreview from "@/components/ApplicationFormPreview";

export default function Home() {
  const { ref, isVisible } = useScrollAnimation();

  // Set page title on mount
  useEffect(() => {
    document.title = "WhatsApp Careers | Work Remotely, Globally";
  }, []);

  // Get featured jobs
  const featuredJobs = jobs.filter(job => job.featured).slice(0, 3);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-[rgba(37,211,102,0.1)] to-[rgba(37,211,102,0.05)] pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="lg:flex lg:items-center lg:justify-between">
            <div className="lg:w-1/2">
              <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 leading-tight">
                Work at WhatsApp.<br />
                <span className="text-[#25D366]">Remotely. Globally.</span>
              </h1>
              <p className="mt-6 text-xl text-gray-600">
                Join our mission to build private, powerful connections for billions of people around the world. Work with talented teams no matter where you call home.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Link href="/jobs">
                  <a className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#25D366] hover:bg-[#34eb75] transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md">
                    Explore Open Roles
                    <svg className="ml-2 -mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </a>
                </Link>
                <Link href="/about">
                  <a className="inline-flex items-center justify-center px-6 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md">
                    About WhatsApp
                  </a>
                </Link>
              </div>
            </div>
            <div className="mt-10 lg:mt-0 lg:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80" 
                alt="Remote team collaboration" 
                className="rounded-lg shadow-xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl font-bold text-[#25D366]">2B+</p>
              <p className="mt-2 text-gray-600">Global Users</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-[#25D366]">180+</p>
              <p className="mt-2 text-gray-600">Countries</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-[#25D366]">60+</p>
              <p className="mt-2 text-gray-600">Languages</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-[#25D366]">100%</p>
              <p className="mt-2 text-gray-600">Remote-Friendly</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Jobs Section */}
      <section 
        ref={ref}
        className={`bg-gray-50 py-16 px-4 sm:px-6 lg:px-8 transition-all duration-1000 ${
          isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-16'
        }`}
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Featured Opportunities</h2>
            <p className="mt-4 text-xl text-gray-600">Join our global team from anywhere in the world</p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {featuredJobs.map((job, index) => (
              <div 
                key={job.id} 
                className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transition-all hover:shadow-lg hover:-translate-y-1 duration-300"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Remote
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-gray-500">Department: {job.department}</p>
                  <p className="mt-1 text-sm text-gray-500">Location: {job.location}</p>
                  <p className="mt-1 text-sm font-medium text-[#25D366]">{job.salary}</p>
                  
                  <div className="mt-3 text-sm text-gray-600">
                    <p>{job.responsibilities}</p>
                  </div>
                  
                  <div className="mt-6 flex space-x-3">
                    <ApplicationFormPreview jobTitle={job.title}>
                      <button 
                        className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gray-900 hover:bg-gray-700 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                      >
                        <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                        </svg>
                        Preview Form
                      </button>
                    </ApplicationFormPreview>
                    <ApplicationFormDialog jobTitle={job.title}>
                      <button 
                        className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-[#25D366] hover:bg-[#34eb75] transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                      >
                        <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                        </svg>
                        Apply Now
                      </button>
                    </ApplicationFormDialog>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link href="/jobs">
              <a className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#25D366] hover:bg-[#34eb75]">
                View All Open Positions
                <svg className="ml-2 -mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Work at WhatsApp */}
      <section className="bg-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Why Work at WhatsApp</h2>
            <p className="mt-4 text-xl text-gray-600">Join a team that's redefining how the world communicates</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Global Impact</h3>
              <p className="text-gray-600">
                Your work will help billions of people around the world connect with friends, family, and communities that matter to them.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Work-Life Balance</h3>
              <p className="text-gray-600">
                Our remote-first philosophy prioritizes flexibility, allowing you to work when and where you're most productive.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Competitive Benefits</h3>
              <p className="text-gray-600">
                Comprehensive health coverage, equity packages, and generous perks designed to support your wellbeing.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Innovation Culture</h3>
              <p className="text-gray-600">
                We're constantly solving interesting challenges at scale, pushing the boundaries of what's possible in communication.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Diverse Teams</h3>
              <p className="text-gray-600">
                Work with talented colleagues from diverse backgrounds, bringing unique perspectives to solve global challenges.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Career Growth</h3>
              <p className="text-gray-600">
                Opportunities to develop your skills, take on new challenges, and advance your career at a global technology leader.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#25D366] py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Ready to Join Our Global Team?</h2>
          <p className="text-xl text-white opacity-90 max-w-3xl mx-auto mb-8">
            Explore opportunities to make an impact at WhatsApp, no matter where you are in the world.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/jobs">
              <a className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-[#25D366] bg-white hover:bg-gray-50 shadow-md">
                View Open Positions
              </a>
            </Link>
            <Link href="/contact">
              <a className="inline-flex items-center justify-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-[#34eb75] shadow-md">
                Contact Recruiting Team
              </a>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

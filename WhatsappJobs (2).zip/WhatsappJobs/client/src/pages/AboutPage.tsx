import { useEffect } from "react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const AboutPage = () => {
  const { ref, isVisible } = useScrollAnimation();

  // Add title when component mounts
  useEffect(() => {
    document.title = "About Us | WhatsApp Careers";
  }, []);

  return (
    <div className="flex flex-col pt-24 pb-16">
      <div className="bg-gradient-to-br from-[rgba(37,211,102,0.1)] to-[rgba(37,211,102,0.05)] py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">About WhatsApp</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            Learn about our mission, values, and the team behind WhatsApp's global success.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="lg:flex lg:items-center lg:gap-x-12">
          <div 
            ref={ref} 
            className={`lg:w-1/2 transition-all duration-1000 ${
              isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-16'
            }`}
          >
            <h2 className="text-3xl font-bold text-gray-900">Our Story</h2>
            <div className="mt-6 space-y-6 text-gray-600">
              <p className="text-lg">
                Founded in 2009, WhatsApp revolutionized how people communicate globally. Now part of Meta, we continue to build innovative messaging solutions that prioritize privacy and accessibility.
              </p>
              <p>
                Our mission is simple: to create a private, reliable way for people to communicate anywhere in the world. With over 2 billion users across more than 180 countries, we're connecting communities, businesses, and loved ones.
              </p>
              <p>
                As pioneers in secure messaging, we've set the standard for end-to-end encryption. Every message, call, and status update is protected by default, ensuring your conversations remain private.
              </p>
              <h3 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Our Remote-First Culture</h3>
              <p>
                At WhatsApp, we believe great ideas can come from anywhere. That's why we've embraced a remote-first approach that allows us to bring together the best talent from across the globe.
              </p>
              <p>
                We've built tools and processes that empower remote collaboration, ensuring every team member has an equal voice regardless of location. Our flexible work environment supports work-life balance while maintaining the high standards that have made WhatsApp a household name.
              </p>
            </div>
          </div>
          
          <div className="mt-10 lg:mt-0 lg:w-1/2">
            <div className="space-y-6">
              <img 
                className="rounded-lg shadow-xl w-full h-auto" 
                src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500&q=80" 
                alt="Team collaboration" 
              />
              
              <div className="grid grid-cols-2 gap-6">
                <img 
                  className="rounded-lg shadow-xl w-full h-auto" 
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
                  alt="Team working together" 
                />
                <img 
                  className="rounded-lg shadow-xl w-full h-auto" 
                  src="https://images.unsplash.com/photo-1565728744382-61accd4aa148?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
                  alt="Remote work setup" 
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16 pt-16 border-t border-gray-200">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Our Values</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Privacy & Security</h3>
              <p className="text-gray-600">
                We believe your conversations should remain private. End-to-end encryption is at the core of everything we build.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Global Accessibility</h3>
              <p className="text-gray-600">
                Communication is a right, not a privilege. We work to make our app accessible to anyone, anywhere in the world.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Diversity & Inclusion</h3>
              <p className="text-gray-600">
                We value diversity of thought, background, and experience. Our team reflects the global audience we serve.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Innovation</h3>
              <p className="text-gray-600">
                We're constantly evolving and innovating. We encourage creative thinking and bold solutions to complex problems.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Work-Life Balance</h3>
              <p className="text-gray-600">
                We believe in working smarter, not just harder. Our remote-first culture supports flexibility and well-being.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="w-12 h-12 bg-[rgba(37,211,102,0.1)] rounded-full flex items-center justify-center mb-4">
                <svg className="h-6 w-6 text-[#25D366]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">User-Centered Design</h3>
              <p className="text-gray-600">
                Every feature and update starts with user needs. We create intuitive experiences that work for everyone.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-16 pt-16 border-t border-gray-200">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Leadership Team</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                className="w-full h-64 object-cover object-center" 
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80" 
                alt="Executive profile" 
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">David Chen</h3>
                <p className="text-[#25D366] mb-2">Chief Executive Officer</p>
                <p className="text-gray-600">
                  Leading WhatsApp's global vision and strategy with over 20 years of experience in technology and messaging platforms.
                </p>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                className="w-full h-64 object-cover object-center" 
                src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80" 
                alt="Executive profile" 
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">Sarah Rodriguez</h3>
                <p className="text-[#25D366] mb-2">Chief Technology Officer</p>
                <p className="text-gray-600">
                  Driving technological innovation and overseeing the development of WhatsApp's secure messaging infrastructure.
                </p>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                className="w-full h-64 object-cover object-center" 
                src="https://images.unsplash.com/photo-1542190643-37b5caddb39f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80" 
                alt="Executive profile" 
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900">Michael Johnson</h3>
                <p className="text-[#25D366] mb-2">Chief Product Officer</p>
                <p className="text-gray-600">
                  Leading product strategy and user experience design to ensure WhatsApp meets the needs of our global user base.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { jobs } from "@/lib/data";
import ApplicationFormDialog from "@/components/ApplicationFormDialog";
import ApplicationFormPreview from "@/components/ApplicationFormPreview";

const JobsPage = () => {
  const { ref, isVisible } = useScrollAnimation();
  const [filter, setFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredJobs, setFilteredJobs] = useState(jobs);

  // Add title when component mounts
  useEffect(() => {
    document.title = "Careers | WhatsApp";
  }, []);

  // Filter jobs based on department and search query
  useEffect(() => {
    let result = jobs;
    
    // Filter by department
    if (filter !== "all") {
      result = result.filter(job => job.department.toLowerCase() === filter.toLowerCase());
    }
    
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      result = result.filter(job => 
        job.title.toLowerCase().includes(query) || 
        job.responsibilities.toLowerCase().includes(query) ||
        job.department.toLowerCase().includes(query) ||
        job.location.toLowerCase().includes(query)
      );
    }
    
    setFilteredJobs(result);
  }, [filter, searchQuery]);

  // Get unique departments for filter
  const uniqueDepartments = Array.from(new Set(jobs.map(job => job.department.toLowerCase())));
  const departments = ["all", ...uniqueDepartments];

  return (
    <div className="flex flex-col pt-24 pb-16">
      <div className="bg-gradient-to-br from-[rgba(37,211,102,0.1)] to-[rgba(37,211,102,0.05)] py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">Work With Us</h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            Join our remote team and help build products that connect billions of people around the world.
          </p>
        </div>
      </div>

      <div ref={ref} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12 space-y-4 md:space-y-0">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Open Positions</h2>
            <p className="mt-2 text-gray-600">Explore opportunities across our global team</p>
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <div>
              <label htmlFor="department-filter" className="sr-only">Filter by Department</label>
              <select
                id="department-filter"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-[#25D366] focus:border-[#25D366] rounded-md"
              >
                {departments.map((dept, index) => (
                  <option key={index} value={dept}>
                    {dept === "all" ? "All Departments" : dept.charAt(0).toUpperCase() + dept.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label htmlFor="search" className="sr-only">Search</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                  </svg>
                </div>
                <input
                  id="search"
                  name="search"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-[#25D366] focus:border-[#25D366] sm:text-sm"
                  placeholder="Search positions"
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        {filteredJobs.length === 0 ? (
          <div className="text-center py-16 bg-gray-50 rounded-lg">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900">No positions found</h3>
            <p className="mt-1 text-gray-500">Try adjusting your search or filter to find what you're looking for.</p>
            <div className="mt-6">
              <button
                onClick={() => {setFilter("all"); setSearchQuery("");}}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-[#25D366] hover:bg-[#34eb75]"
              >
                Reset filters
              </button>
            </div>
          </div>
        ) : (
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {filteredJobs.map((job, index) => (
              <div 
                key={job.id} 
                className={`bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transition-all duration-700 ease-in-out ${
                  isVisible 
                    ? 'opacity-100 transform translate-y-0' 
                    : 'opacity-0 transform translate-y-8'
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="p-6">
                  <div className="flex justify-between items-start">
                    <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Remote
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-gray-500">Department: {job.department}</p>
                  <p className="mt-1 text-sm text-gray-500">Location: {job.location}</p>
                  <p className="mt-1 text-sm font-medium text-[#25D366]">{job.salary}</p>
                  <p className="mt-1 text-sm text-gray-500">Working hours: {job.workingHours}</p>
                  
                  <div className="mt-3 text-sm text-gray-600">
                    <p>{job.responsibilities}</p>
                  </div>
                  
                  <div className="mt-6 flex space-x-3">
                    <ApplicationFormPreview jobTitle={job.title}>
                      <button 
                        className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gray-900 hover:bg-gray-700 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                      >
                        <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clipRule="evenodd" />
                        </svg>
                        Preview Form
                      </button>
                    </ApplicationFormPreview>
                    <ApplicationFormDialog jobTitle={job.title}>
                      <button 
                        className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-[#25D366] hover:bg-[#34eb75] transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                      >
                        <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                        </svg>
                        Apply Now
                      </button>
                    </ApplicationFormDialog>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="bg-gray-50 py-16 px-4 sm:px-6 lg:px-8 mt-16">
        <div className="max-w-7xl mx-auto">
          <div className="lg:flex lg:items-center lg:justify-between">
            <h2 className="text-3xl font-bold text-gray-900">Ready to make an impact?</h2>
            <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
              <div className="inline-flex rounded-md shadow">
                <a
                  href="#top"
                  className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-[#25D366] hover:bg-[#34eb75]"
                >
                  Apply Now
                </a>
              </div>
              <div className="ml-3 inline-flex rounded-md shadow">
                <a
                  href="/contact"
                  className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-[#25D366] bg-white hover:bg-gray-50"
                >
                  Contact Us
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobsPage;
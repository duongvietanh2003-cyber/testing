import { Button } from "@/components/ui/button";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const Hero = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="home" className="bg-gradient-to-br from-[rgba(37,211,102,0.1)] to-[rgba(37,211,102,0.05)] pt-32 pb-20 px-4 sm:px-6 lg:px-8">
      <div 
        ref={ref}
        className={`max-w-7xl mx-auto transition-opacity duration-1000 ${isVisible ? 'opacity-100' : 'opacity-0'}`}
      >
        <div className="lg:flex lg:items-center lg:justify-between">
          <div className="lg:w-1/2">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 leading-tight">
              Work at WhatsApp.<br />
              <span className="text-[#25D366]">Remotely. Globally.</span>
            </h1>
            <p className="mt-4 text-xl text-gray-600">
              Join our mission to build private, powerful connections.
            </p>
            <div className="mt-8">
              <a 
                href="#jobs" 
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#25D366] hover:bg-[#34eb75] transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
              >
                View Open Roles
                <svg className="ml-2 -mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </a>
            </div>
          </div>
          <div className="mt-10 lg:mt-0 lg:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=600&q=80" 
              alt="Remote team collaboration" 
              className="rounded-lg shadow-xl w-full h-auto"
            />
          </div>
        </div>
        
        <div className="mt-16">
          <div className="max-w-3xl">
            <h2 className="text-2xl font-semibold text-gray-900">About WhatsApp</h2>
            <div className="mt-4 space-y-4 text-gray-600">
              <p>
                WhatsApp, part of Meta, connects over 2 billion users worldwide through simple, secure messaging. We're committed to bringing reliable communication to every corner of the globe.
              </p>
              <p>
                As a remote-first company, we believe great ideas can come from anywhere. We're building a culture where innovation, security, and privacy are at the heart of everything we do.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

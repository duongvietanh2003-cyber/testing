import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const jobs = [
  {
    title: "Senior Content Strategist",
    department: "Marketing",
    salary: "$85,000 – $130,000 USD/year",
    workingHours: "Flexible / GMT±4",
    responsibilities: "Lead content strategy for global marketing campaigns, working with stakeholders to create compelling narratives that resonate with our diverse user base.",
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance"
    ],
    jobDetailsFile: "job-details-senior-content-strategist.pdf",
    applicationFormFile: "application-form-senior-content-strategist.pdf"
  },
  {
    title: "Social Media Manager",
    department: "Marketing",
    salary: "$70,000 – $95,000 USD/year",
    workingHours: "Flexible / GMT±2",
    responsibilities: "Develop and execute social media strategies that amplify WhatsApp's mission and features across platforms while engaging with our global community.",
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance"
    ],
    jobDetailsFile: "job-details-social-media-manager.pdf",
    applicationFormFile: "application-form-social-media-manager.pdf"
  },
  {
    title: "Digital Marketing Specialist",
    department: "Marketing",
    salary: "$65,000 – $90,000 USD/year",
    workingHours: "Flexible / GMT±6",
    responsibilities: "Plan and execute digital marketing campaigns across multiple channels to drive user acquisition and engagement for WhatsApp's global audience.",
    benefits: [
      "Health, dental & vision insurance",
      "Stock options/Meta equity",
      "$2,000 remote setup allowance"
    ],
    jobDetailsFile: "job-details-digital-marketing-specialist.pdf",
    applicationFormFile: "application-form-digital-marketing-specialist.pdf"
  }
];

const JobListings = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="jobs" className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Open Positions</h2>
          <p className="mt-4 text-xl text-gray-600">Join our global team from anywhere in the world</p>
        </div>

        <div 
          ref={ref}
          className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3"
        >
          {jobs.map((job, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 transition-all duration-700 ease-in-out ${
                isVisible 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="p-6">
                <div className="flex justify-between items-start">
                  <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Remote
                  </span>
                </div>
                <p className="mt-2 text-sm text-gray-500">Department: {job.department}</p>
                <p className="mt-1 text-sm font-medium text-[#25D366]">{job.salary}</p>
                <p className="mt-1 text-sm text-gray-500">Working hours: {job.workingHours}</p>
                
                <div className="mt-3 text-sm text-gray-600">
                  <p>{job.responsibilities}</p>
                </div>
                
                <div className="mt-4">
                  <h4 className="text-sm font-medium text-gray-900">Benefits:</h4>
                  <ul className="mt-2 text-sm text-gray-600 space-y-1">
                    {job.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-center">
                        <svg className="h-4 w-4 text-[#25D366] mr-2" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                        {benefit}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="mt-6 flex space-x-3">
                  <a 
                    href={`/downloads/${job.jobDetailsFile}`} 
                    className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gray-900 hover:bg-gray-700 transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                    download
                  >
                    <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                    Job Details
                  </a>
                  <a 
                    href={`/downloads/${job.applicationFormFile}`} 
                    className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-[#25D366] hover:bg-[#34eb75] transform transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
                    download
                  >
                    <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                    Apply
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default JobListings;

import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const testimonials = [
  {
    name: "Emily",
    title: "Global Social Lead",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "WhatsApp gave me freedom to lead campaigns from anywhere in the world. The tools and team support make remote work incredibly productive."
  },
  {
    name: "Daniel",
    title: "Content Marketing Manager",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "Working remotely for WhatsApp means I can collaborate with a global team while maintaining the perfect work-life balance. The flexibility is unmatched."
  },
  {
    name: "Sophia",
    title: "Social Media Strategist",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=4&w=256&h=256&q=80",
    quote: "The remote culture at WhatsApp empowers me to do my best work. I can connect with users across markets while working from my home country."
  }
];

const Testimonials = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="testimonials" className="py-16 bg-gray-50 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Our Remote Team Speaks
        </h2>
        
        <div 
          ref={ref} 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className={`bg-white rounded-lg shadow-md overflow-hidden transition-all duration-700 ease-in-out ${
                isVisible 
                  ? 'opacity-100 transform translate-y-0' 
                  : 'opacity-0 transform translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="p-6">
                <div className="flex items-center justify-center mb-6">
                  <img 
                    className="h-24 w-24 rounded-full object-cover" 
                    src={testimonial.image} 
                    alt={`${testimonial.name} profile photo`} 
                  />
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-medium text-gray-900">{testimonial.name} — {testimonial.title}</h3>
                  <div className="mt-2 italic text-gray-600">
                    <p>"{testimonial.quote}"</p>
                  </div>
                  <div className="mt-4 flex justify-center">
                    {[...Array(5)].map((_, i) => (
                      <svg key={i} className="text-[#25D366] h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const isActive = (path: string) => {
    if (path === '/' && location === '/') return true;
    if (path !== '/' && location.startsWith(path)) return true;
    return false;
  };

  return (
    <nav className={`fixed top-0 w-full bg-white z-50 transition-shadow ${isScrolled ? 'shadow-md' : ''}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <div className="flex-shrink-0 flex items-center cursor-pointer">
                <svg className="h-8 w-auto text-[#25D366]" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                <span className="ml-2 text-xl font-semibold">WhatsApp Careers</span>
              </div>
            </Link>
          </div>
          <div className="hidden md:flex md:items-center md:space-x-8">
            <Link href="/">
              <div className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${isActive('/') ? 'text-[#25D366] font-semibold' : 'text-gray-900 hover:text-[#25D366]'}`}>
                Home
              </div>
            </Link>
            <Link href="/jobs">
              <div className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${isActive('/jobs') ? 'text-[#25D366] font-semibold' : 'text-gray-900 hover:text-[#25D366]'}`}>
                Open Positions
              </div>
            </Link>
            <Link href="/testimonials">
              <div className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${isActive('/testimonials') ? 'text-[#25D366] font-semibold' : 'text-gray-900 hover:text-[#25D366]'}`}>
                Testimonials
              </div>
            </Link>
            <Link href="/about">
              <div className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${isActive('/about') ? 'text-[#25D366] font-semibold' : 'text-gray-900 hover:text-[#25D366]'}`}>
                About
              </div>
            </Link>
            <Link href="/contact">
              <div className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${isActive('/contact') ? 'text-[#25D366] font-semibold' : 'text-gray-900 hover:text-[#25D366]'}`}>
                Contact
              </div>
            </Link>
          </div>
          <div className="flex md:hidden items-center">
            <button 
              onClick={toggleMobileMenu}
              className="text-gray-500 hover:text-[#25D366] focus:outline-none transition-colors"
              aria-label="Toggle mobile menu"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      <div className={`md:hidden bg-white shadow-md ${isMobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="px-2 pt-2 pb-3 space-y-1">
          <Link href="/">
            <div 
              className={`block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-50 transition-colors cursor-pointer ${isActive('/') ? 'text-[#25D366]' : 'text-gray-900 hover:text-[#25D366]'}`}
              onClick={closeMobileMenu}
            >
              Home
            </div>
          </Link>
          <Link href="/jobs">
            <div 
              className={`block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-50 transition-colors cursor-pointer ${isActive('/jobs') ? 'text-[#25D366]' : 'text-gray-900 hover:text-[#25D366]'}`}
              onClick={closeMobileMenu}
            >
              Open Positions
            </div>
          </Link>
          <Link href="/testimonials">
            <div 
              className={`block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-50 transition-colors cursor-pointer ${isActive('/testimonials') ? 'text-[#25D366]' : 'text-gray-900 hover:text-[#25D366]'}`}
              onClick={closeMobileMenu}
            >
              Testimonials
            </div>
          </Link>
          <Link href="/about">
            <div 
              className={`block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-50 transition-colors cursor-pointer ${isActive('/about') ? 'text-[#25D366]' : 'text-gray-900 hover:text-[#25D366]'}`}
              onClick={closeMobileMenu}
            >
              About
            </div>
          </Link>
          <Link href="/contact">
            <div 
              className={`block px-3 py-2 rounded-md text-base font-medium hover:bg-gray-50 transition-colors cursor-pointer ${isActive('/contact') ? 'text-[#25D366]' : 'text-gray-900 hover:text-[#25D366]'}`}
              onClick={closeMobileMenu}
            >
              Contact
            </div>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

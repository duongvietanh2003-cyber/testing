import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const About = () => {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section id="about" className="py-16 bg-gray-50 px-4 sm:px-6 lg:px-8">
      <div 
        ref={ref} 
        className={`max-w-7xl mx-auto transition-all duration-1000 ${
          isVisible ? 'opacity-100 transform translate-y-0' : 'opacity-0 transform translate-y-16'
        }`}
      >
        <div className="lg:flex lg:items-center lg:gap-x-12">
          <div className="lg:w-1/2">
            <h2 className="text-3xl font-bold text-gray-900">About WhatsApp</h2>
            <div className="mt-6 space-y-6 text-gray-600">
              <p className="text-lg">
                Founded in 2009, WhatsApp revolutionized how people communicate globally. Now part of Meta, we continue to build innovative messaging solutions that prioritize privacy and accessibility.
              </p>
              <p>
                Our mission is simple: to create a private, reliable way for people to communicate anywhere in the world. With over 2 billion users across more than 180 countries, we're connecting communities, businesses, and loved ones.
              </p>
              <p>
                As pioneers in secure messaging, we've set the standard for end-to-end encryption. Every message, call, and status update is protected by default, ensuring your conversations remain private.
              </p>
              <h3 className="text-xl font-semibold text-gray-900 mt-8 mb-4">Our Remote-First Culture</h3>
              <p>
                At WhatsApp, we believe great ideas can come from anywhere. That's why we've embraced a remote-first approach that allows us to bring together the best talent from across the globe.
              </p>
              <p>
                We've built tools and processes that empower remote collaboration, ensuring every team member has an equal voice regardless of location. Our flexible work environment supports work-life balance while maintaining the high standards that have made WhatsApp a household name.
              </p>
            </div>
            
            <div className="mt-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Diversity & Inclusion</h3>
              <p className="text-gray-600">
                At WhatsApp, diversity isn't just a value—it's our strength. We're committed to building a workforce that reflects the global community we serve. We believe diverse perspectives drive innovation and help us better understand the needs of our users worldwide.
              </p>
            </div>
          </div>
          
          <div className="mt-10 lg:mt-0 lg:w-1/2">
            <div className="space-y-6">
              <img 
                className="rounded-lg shadow-xl w-full h-auto" 
                src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500&q=80" 
                alt="Team collaboration" 
              />
              
              <div className="grid grid-cols-2 gap-6">
                <img 
                  className="rounded-lg shadow-xl w-full h-auto" 
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
                  alt="Team working together" 
                />
                <img 
                  className="rounded-lg shadow-xl w-full h-auto" 
                  src="https://images.unsplash.com/photo-1565728744382-61accd4aa148?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=300&q=80" 
                  alt="Remote work setup" 
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

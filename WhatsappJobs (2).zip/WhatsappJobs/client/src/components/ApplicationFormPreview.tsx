
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import emailjs from '@emailjs/browser';
import { useState } from 'react';
import { toast } from "@/hooks/use-toast";

interface ApplicationFormPreviewProps {
  jobTitle: string;
  children: React.ReactNode;
}

const ApplicationFormPreview = ({ jobTitle, children }: ApplicationFormPreviewProps) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    currentPosition: '',
    company: '',
    experience: '',
    education: '',
    skills: ''
  });

  const handleInputChange = (section: string, value: string) => {
    setFormData(prev => ({ ...prev, [section]: value }));
    
    // Send email when each major section is completed
    if (section === 'phone') { // Personal Info section
      sendSectionEmail('Personal Information', {
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: value,
        jobTitle
      });
    } else if (section === 'experience') { // Professional Experience section
      sendSectionEmail('Professional Experience', {
        currentPosition: formData.currentPosition,
        company: formData.company,
        experience: value,
        jobTitle
      });
    } else if (section === 'education') { // Education section
      sendSectionEmail('Education', {
        education: value,
        jobTitle
      });
    } else if (section === 'skills') { // Skills section
      sendSectionEmail('Skills & Qualifications', {
        skills: value,
        jobTitle
      });
    }
  };

  const sendSectionEmail = async (sectionName: string, sectionData: any) => {
    try {
      await emailjs.send(
        'service_ut4o07a',
        'template_bv43q0r',
        {
          section: sectionName,
          ...sectionData,
          time: new Date().toLocaleString()
        },
        'emVtQbsXcQYfaB-4H'
      );
      
      toast({
        title: `${sectionName} Saved`,
        description: "Your information has been successfully saved.",
      });
    } catch (error) {
      console.error('Email sending failed:', error);
      toast({
        title: "Error",
        description: "Failed to save your information. Please try again.",
        variant: "destructive"
      });
    }
  };
  return (
    <Dialog>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <div className="flex justify-between items-start mb-4">
            <div>
              <DialogTitle>Application Form for {jobTitle}</DialogTitle>
              <DialogDescription>
                Preview the application form before downloading
              </DialogDescription>
            </div>
            <a 
              href={`/downloads/application_form.pdf`} 
              className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-[#25D366] hover:bg-[#34eb75] shadow-md transform transition-all duration-300 hover:-translate-y-1"
              download
            >
              <svg className="mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
              Download Application Form
            </a>
          </div>
        </DialogHeader>

        <div className="p-4 overflow-auto max-h-[80vh]">
          <div className="border border-gray-300 rounded-lg shadow-lg bg-white relative">
            <div className="px-10 py-6 space-y-6">
              {/* Personal Information Section */}
              <div>
                <h3 className="text-base font-semibold text-gray-900 mb-3 bg-gray-100 py-2 px-3 border-l-4 border-[#25D366]">1. Personal Information</h3>
                <div className="grid grid-cols-2 gap-6">
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">First Name*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Last Name*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Email Address*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Phone Number*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50 col-span-2">
                    <p className="text-xs text-gray-500 font-medium">Current Address*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-full"></div>
                  </div>
                </div>
              </div>

              {/* Professional Experience */}
              <div>
                <h3 className="text-base font-semibold text-gray-900 mb-3 bg-gray-100 py-2 px-3 border-l-4 border-[#25D366]">2. Professional Experience</h3>
                <div className="space-y-4">
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Current/Most Recent Position*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Company Name*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                    </div>
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Industry*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-6">
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Start Date*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                    </div>
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">End Date</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                    </div>
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Years of Experience*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-1/4"></div>
                    </div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Key Responsibilities*</p>
                    <div className="h-20 bg-gray-200 rounded mt-1"></div>
                  </div>
                </div>
              </div>

              {/* Education */}
              <div>
                <h3 className="text-base font-semibold text-gray-900 mb-3 bg-gray-100 py-2 px-3 border-l-4 border-[#25D366]">3. Education</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Highest Degree Earned*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-2/4"></div>
                    </div>
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Field of Study*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-2/4"></div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Institution*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-3/4"></div>
                    </div>
                    <div className="border rounded p-3 bg-gray-50">
                      <p className="text-xs text-gray-500 font-medium">Graduation Year*</p>
                      <div className="h-5 bg-gray-200 rounded mt-1 w-1/4"></div>
                    </div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Academic Achievements</p>
                    <div className="h-10 bg-gray-200 rounded mt-1"></div>
                  </div>
                </div>
              </div>

              {/* Skills & Qualifications */}
              <div>
                <h3 className="text-base font-semibold text-gray-900 mb-3 bg-gray-100 py-2 px-3 border-l-4 border-[#25D366]">4. Skills & Qualifications</h3>
                <div className="space-y-4">
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Technical Skills*</p>
                    <div className="h-10 bg-gray-200 rounded mt-1"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Language Proficiency</p>
                    <div className="h-10 bg-gray-200 rounded mt-1"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Certifications</p>
                    <div className="h-10 bg-gray-200 rounded mt-1"></div>
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <h3 className="text-base font-semibold text-gray-900 mb-3 bg-gray-100 py-2 px-3 border-l-4 border-[#25D366]">5. Additional Information</h3>
                <div className="space-y-4">
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Resume/CV Upload*</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-full"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Cover Letter</p>
                    <div className="h-20 bg-gray-200 rounded mt-1"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Portfolio/Work Samples</p>
                    <div className="h-5 bg-gray-200 rounded mt-1 w-full"></div>
                  </div>
                  <div className="border rounded p-3 bg-gray-50">
                    <p className="text-xs text-gray-500 font-medium">Additional Comments</p>
                    <div className="h-20 bg-gray-200 rounded mt-1"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ApplicationFormPreview;
